const express = require('express');
const app = express();
app.set('view engine', 'ejs');
app.set('views', './views');

const { uploadSingle, uploadArray } = require('./upload.js');

app.use(express.static('public'));
app.listen(3000, () => console.log('Server started'));
const parser = require('body-parser').urlencoded({ extended: false });
// let {mangTin, Tin} = require('./Tin.js');

const { Tin, mangTin } = require('./Tin.js');

const { queryDB, removeNews, addNews, updateNews, getNewsById } = require('./db');

app.get('/', (req, res) => {
  queryDB('SELECT * FROM "News"', (err, result) => {
    if (err) return res.send(`${err }`);
    res.render('index', {
      username: 'khoapham',
      mangTin: result.rows
    });
  });
});


// app.use('/home', require('./routes/home.js'));
app.use('/home', require('./routes/uploadfile.js'));

app.get('/admin', (req, res) => queryDB('SELECT * FROM "News"', (err, tin) => {
    if (err) return res.send(`${err}`);
    res.render('admin', {
      username: 'khoapham',
      mangTin: tin.rows
    });
  })
  );

app.get('/admin/news', (req, res) => res.render('add'));

app.post('/admin/news', parser, (req, res) => {
  const { title, desc, date, image } = req.body;
  const tin = new Tin(title, desc, image, date);
  addNews(tin.title, tin.desc, tin.image, tin.date, (err) => {
    if (err) return res.send(`${err}`);
    res.redirect('/admin');
  });
});

app.get('/admin/xoa/:index', (req, res) => {
  const { index } = req.params;
  removeNews(index, (err) => {
    if (err) res.send(`${err}`);
    res.redirect('/admin');
  });
});

app.get('/admin/sua/:index', (req, res) => {
  const { index } = req.params;
  getNewsById(index, (err, result) => {
    if (err || result.rows.length === 0) return res.send(`${err}`);
    const { title, desc, image, date } = result.rows[0];
    const tin = new Tin(title, desc, image, date);
    res.render('update', { tin, index });
  });
});

//req.file.filename

app.post('/admin/sua', (req, res) => {
  uploadSingle('avatar')(req, res, err => {
    if (err) return res.send(err);
    const { title, desc, date, index } = req.body;
    const image = req.file ? req.file.filename : req.body.old;
    const tin = new Tin(title, desc, image, date);
    updateNews(index, tin, (err, result) => {
      if (err) return res.send(`${err}`);
      res.redirect('/admin');
    });
  });
});

app.get('/array', (req, res) => res.render('arrayfile'));

app.post('/array', (req, res) => {
  uploadArray('avatar')(req, res, err => {
    res.send(req.files);
  });
});
